package com.capgemini.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.model.Merchant;

@Controller
public class JspController {
	
	@RequestMapping(value="/")
	public ModelAndView consumeQuote(){
		return new ModelAndView("index");
	}
	@RequestMapping("/index")
	public String consume(){
		return "index";
	}
	@RequestMapping(value="/Inventory")
	public String consumeQuote1(){
		return "Inventory";
	}
	@RequestMapping(value="/MerchantDetails")
	public String consumeQuote2(){
		return "MerchantDetails";
	}
		
	@RequestMapping(value="/CustomerDetails")
	public String consumeQuote3(){
		return "CustomerDetails";
	}
	
	@RequestMapping(value="/ProductStatus")
	public String consumeQuote4(){
		return "ProductStatus";
	}
	@RequestMapping(value="/GenerateReports")
	public String consumeQuote5(){
		return "GenerateReports";
	}
	
	@RequestMapping(value="/MerchantRequest")
	public String consumeQuote6(){
		return "MerchantRequest";
	}
	@RequestMapping(value="/ProductRequest")
	public String consumeQuote7(){
		return "ProductRequest";
	}
	@RequestMapping(value="/AddPromo")
	public String consumeQuote8(){
		return "AddPromo";
	}
	@RequestMapping(value="/ProductResult")
	public String consumeQuote9(){
		return "ProductResult";
	}
	@RequestMapping(value="/CategoryResult")
	public String consumeQuote10(){
		return "CategoryResult";
	}
	@RequestMapping(value="/MerchantResult")
	public String consumeQuote11(){
		return "MerchantResult";
	}
	@RequestMapping(value="/AcceptMReq")
	public String consumeQuote12(){
		return "AcceptMReq";
	}
	@RequestMapping(value="/ViewDetails")
	public String consumeQuote13(){
		return "ViewDetails";
	}
	/*@RequestMapping(value="/index")
	public @ResponseBody Merchant consumeMessage(){
		RestTemplate restTemplate = new RestTemplate();
		Merchant message = restTemplate.getForObject("http://localhost:9890/test.json", Merchant.class);
		return message;
	}*/
	
}
